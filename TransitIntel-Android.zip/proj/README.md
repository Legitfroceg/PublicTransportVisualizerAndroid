# AI Transit Intelligence – offline Android app (TFLite)

Fully offline: the app has **no INTERNET permission**. Forecasts come from `transit_model.tflite`,
run on the phone by the TensorFlow Lite interpreter.

```
android/                      Android Studio / Gradle project (Kotlin + Jetpack Compose)
  app/src/main/assets/
    transit_model.tflite      trained model (14 KB)
    transit_meta.json         routes, capacities, typical hourly load, KPIs, model quality
tflite_export/
  train_and_export.py         trains the model and writes the two asset files
.github/workflows/build-apk.yml   builds the APK in the cloud (GitHub Actions)
```

## Build the APK

**A. No computer needed for the build: GitHub Actions**
1. Put this whole folder in a GitHub repository (keep the folder structure; `.github/` must be at the repo root).
2. Open the repo's **Actions** tab, then **Build APK**, then **Run workflow** (it also runs on every push).
3. When it finishes (~5 min), open the run and download the **TransitIntel-debug-apk** artifact. Unzip it and install `app-debug.apk`
   (allow "install unknown apps" for your browser/file manager).

**B. Android Studio**: open the `android/` folder, let Gradle sync, then **Build > Build APK(s)**.
Output: `android/app/build/outputs/apk/debug/app-debug.apk`.

## Use your own data (retrain)
```
pip install -r tflite_export/requirements.txt
python tflite_export/train_and_export.py --csv my_data.csv
```
Required CSV columns: timestamp **with time of day**, route, ridership. Optional: capacity, station, mode, weather
(common alternative names are auto-detected, see `ALIASES` in the script). The script overwrites the two files in
`assets/`; rebuild the APK to ship them. With no `--csv` it uses synthetic demo data.

## Notes
- The model is a small neural network predicting occupancy (ridership / capacity). A Random Forest can't be converted to `.tflite`.
- The TensorFlow version for export (2.16.x) and the Android runtime (`tensorflow-lite:2.16.1`) are matched on purpose; keep them in step.
- Citizen reports are stored on the device only.
- Not in the offline app: CSV upload / retraining on the phone, CSV export, data-quality report. Retraining happens in Python (above).
