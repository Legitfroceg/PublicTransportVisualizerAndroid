# Transit Intel – offline Mumbai Suburban Railway app (TFLite)

Fully offline: the app has **no INTERNET permission**. Delay forecasts come from
`transit_model.tflite`, run on the phone by the TensorFlow Lite interpreter.

## What is real and what is modelled — read this first

**REAL** (from public Indian Railways line references, 2026):

- The six lines: **Western, Central, Harbour, Trans-Harbour, Port, Vasai Road–Roha**.
- The running order of every station on each line, the **station names** and the
  real **station codes** (e.g. `Dadar = DDR/D`, `Kurla = C`, `Thane = T`).
- Interchange stations (`Dadar`, `Kurla`, `Thane`, `Wadala Road`, `Panvel`, …),
  the termini (`Churchgate`, `Dahanu Road`, `Kasara`, `Khopoli`, `Roha`, `Uran`, …)
  and the branch corridors (Kasara / Khopoli / Navi Mumbai / Salsette–Goregaon).

**MODELLED** (not official railway data):

- `ridership`, `occupancy_pct`, `crowd_index`, `crowd_label`, `delay_min`,
  `headway_min`, `train_capacity`, `service_status`.

Indian Railways does **not** publish per-station / per-hour suburban delay or
ridership data. Those columns are generated from a documented model of Mumbai
commuting (twin peaks 8–11 & 17–21, Sunday mega-block, monsoon/waterlogging
penalties, AC vs fast vs slow load). Every dataset row carries
`data_source = "modelled"` — **do not present these numbers as official figures.**

## What ships inside the APK (`android/app/src/main/assets/`)

```
mumbai_network.json              real line -> ordered station list (name, code, interchange)
transit_meta.json                encodings the model + UI use (lines, 143 stations, types, ...)
mumbai_transit_dataset.csv.gz    modelled operations dataset, 300,720 rows x 27 columns (~4 MB)
transit_model.tflite             on-device delay model (6 inputs -> delay in minutes)
```

### Dataset columns (27)

```
record_id, service_date, hour_of_day, day_of_week, day_name, is_weekend, is_peak,
is_mega_block, season, month, line, corridor, station, station_code, sequence_no,
is_interchange, commute_type, weather_condition, train_capacity, headway_min,
ridership, occupancy_pct, crowd_index, crowd_label, delay_min, service_status, data_source
```

## Build the APK

**A. No computer needed: GitHub Actions**
1. Put this folder in a GitHub repository (keep the structure; `.github/` at the repo root).
2. **Actions** tab → **Build APK** → **Run workflow** (also runs on every push).
3. Download the **TransitIntel-debug-apk** artifact, unzip, install `app-debug.apk`.

**B. Android Studio**: open the `android/` folder, Gradle sync, then **Build > Build APK(s)**.

## Regenerate everything (assets are generated, not hand-edited)

```
pip install -r tflite_export/requirements.txt
python tflite_export/train_and_export.py              # full dataset (~300k rows)
python tflite_export/train_and_export.py 50000        # smaller dataset (optional)
```

The script holds the real network lists (`NETWORK`) and writes **all** assets, so the
encodings used at training time can never drift from the ones the phone uses. To change
the network or the model, edit `train_and_export.py` and re-run, then rebuild the APK.

- `tflite_export/dataset_sample.csv` is a 300-row preview of the full dataset.
- TensorFlow 2.16 defaults to Keras 3, whose symbolic ops currently break the TFLite
  converter (`LLVM ERROR: Failed to infer result type(s)`). `requirements.txt` pins
  `tf-keras` and the script sets `TF_USE_LEGACY_KERAS=1` to export through Keras 2.

## Notes

- TensorFlow for export (2.16.x) and the Android runtime (`tensorflow-lite:2.16.1`) are
  matched on purpose; keep them in step.
- Citizen reports are stored on the device only (SharedPreferences).
