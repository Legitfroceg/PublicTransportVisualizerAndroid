package com.transit.intel

// ---------- data model (loaded from assets/transit_meta.json) ----------

data class TransitMeta(
    val version: String,
    val city: String,
    val lines: List<String>,
    val stations: List<String>,
    val transitTypes: List<String>,
    val crowdLabels: List<String>,
    val weatherConditions: List<String>,
)

/** All service hours the app forecasts (matches the training data range). */
val SERVICE_HOURS: List<Int> = (4..23).toList()

/** Anything that maps a feature vector to predicted delay in minutes. */
interface DelayModel {
    fun predictDelay(features: FloatArray): Double
}

enum class DelayRisk(val label: String, val emoji: String, val argb: Long) {
    ON_TIME("On time", "🟢", 0xFF2E7D32),
    MINOR("Minor delay", "🟡", 0xFF9A7B00),
    MODERATE("Moderate delay", "🟠", 0xFFE65100),
    SEVERE("Severe delay", "🔴", 0xFFC62828),
}

data class CrowdLevel(val index: Int, val label: String, val argb: Long)

data class DelayForecast(val hour: Int, val delayMins: Double, val risk: DelayRisk, val crowd: CrowdLevel)

data class TripOption(val type: String, val forecast: DelayForecast)

data class ScenarioResult(val weather: String, val delayMins: Double, val risk: DelayRisk)

/** Fixed rules that must mirror the Mumbai logic used to build the training data. */
object Rules {
    val MORNING_PEAK = 8..11
    val EVENING_PEAK = 17..21
    const val SUNDAY = 6 // 0 = Monday ... 6 = Sunday, matching the training data

    fun isPeak(hour: Int) = hour in MORNING_PEAK || hour in EVENING_PEAK
    fun isMegaBlock(dayIndex: Int) = dayIndex == SUNDAY

    fun delayRisk(delayMins: Double): DelayRisk = when {
        delayMins < 5 -> DelayRisk.ON_TIME
        delayMins < 15 -> DelayRisk.MINOR
        delayMins < 30 -> DelayRisk.MODERATE
        else -> DelayRisk.SEVERE
    }

    /** Mirrors the crowd_scores rules used to generate the training targets. */
    fun crowdIndex(hour: Int, dayIndex: Int): Int = when {
        isPeak(hour) -> 3
        isMegaBlock(dayIndex) && hour > 10 -> 2
        hour in 12..16 || hour == 6 || hour == 7 -> 1
        else -> 0
    }

    fun crowdLevel(index: Int, labels: List<String>): CrowdLevel {
        val i = index.coerceIn(0, (labels.size - 1).coerceAtLeast(0))
        val argb = when (i) {
            0 -> 0xFF2E7D32
            1 -> 0xFF9A7B00
            2 -> 0xFFE65100
            else -> 0xFFC62828
        }
        return CrowdLevel(i, labels.getOrElse(i) { "Unknown" }, argb)
    }
}

// ---------- forecasting with the TFLite model ----------

class Forecaster(val meta: TransitMeta, private val model: DelayModel) {

    /**
     * Feature order must match train_and_export.py exactly:
     * hour_of_day, day_of_week, line_encoded, station_encoded, type_encoded, weather_encoded.
     */
    fun features(line: String, station: String, type: String, weather: String, hour: Int, dayIndex: Int): FloatArray =
        floatArrayOf(
            hour.toFloat(),
            dayIndex.toFloat(),
            meta.lines.indexOf(line).coerceAtLeast(0).toFloat(),
            meta.stations.indexOf(station).coerceAtLeast(0).toFloat(),
            meta.transitTypes.indexOf(type).coerceAtLeast(0).toFloat(),
            meta.weatherConditions.indexOf(weather).coerceAtLeast(0).toFloat(),
        )

    fun delay(line: String, station: String, type: String, weather: String, hour: Int, dayIndex: Int): Double =
        model.predictDelay(features(line, station, type, weather, hour, dayIndex)).coerceAtLeast(0.0)

    fun forecast(line: String, station: String, type: String, weather: String, hour: Int, dayIndex: Int): DelayForecast {
        val d = delay(line, station, type, weather, hour, dayIndex)
        return DelayForecast(hour, d, Rules.delayRisk(d), Rules.crowdLevel(Rules.crowdIndex(hour, dayIndex), meta.crowdLabels))
    }

    /** Every service hour for one trip on one day. */
    fun dayForecast(line: String, station: String, type: String, weather: String, dayIndex: Int): List<DelayForecast> =
        SERVICE_HOURS.map { forecast(line, station, type, weather, it, dayIndex) }

    /** The three commute types at one hour, least delayed first. */
    fun compareTypes(line: String, station: String, weather: String, hour: Int, dayIndex: Int): List<TripOption> =
        meta.transitTypes.map { t -> TripOption(t, forecast(line, station, t, weather, hour, dayIndex)) }
            .sortedBy { it.forecast.delayMins }

    /** The same trip under every weather condition. */
    fun weatherScenarios(line: String, station: String, type: String, hour: Int, dayIndex: Int): List<ScenarioResult> =
        meta.weatherConditions.map { w ->
            val d = delay(line, station, type, w, hour, dayIndex)
            ScenarioResult(w, d, Rules.delayRisk(d))
        }
}
