package com.transit.intel

import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ---------- data model (loaded from assets/transit_meta.json) ----------

data class RouteMeta(
    val name: String,
    val mode: String,
    val capacity: Double,
    val stations: List<String>,
    val hourlyMeanOcc: List<Double>,
)

data class ModelMetrics(val modelMae: Double, val modelR2: Double, val baselineMae: Double, val beatsBaseline: Boolean)

data class Kpis(
    val records: Int,
    val totalRidership: Long,
    val avgRidership: Int,
    val peakHour: Int,
    val topRoute: String,
    val busiestStation: String,
    val overcapacityRecords: Int,
)

data class Meta(
    val routes: List<RouteMeta>,
    val weathers: List<String>,
    val defaultWeather: String,
    val serviceHours: List<Int>,
    val rmseOcc: Double,
    val meanRidership: Double,
    val metrics: ModelMetrics,
    val kpis: Kpis,
) {
    val modes: List<String> get() = listOf("All modes") + routes.map { it.mode }.distinct().sorted()
    val stations: List<String> get() = routes.flatMap { it.stations }.distinct().sorted()
    fun route(name: String): RouteMeta = routes.first { it.name == name }
}

/** Anything that maps a feature vector to predicted occupancy (ridership / capacity). */
interface DemandModel {
    fun predictOccupancy(features: FloatArray): Double
}

// ---------- risk + allocation rules (same rules as the web app) ----------

enum class Risk(val label: String, val emoji: String, val argb: Long) {
    LOW("Low", "🟢", 0xFF2E7D32),
    MODERATE("Moderate", "🟡", 0xFF9A7B00),
    HIGH("High", "🟠", 0xFFE65100),
    CRITICAL("Critical", "🔴", 0xFFC62828),
    OVERCAPACITY("Overcapacity", "🔴", 0xFFB71C1C),
}

data class Allocation(val status: String, val addVehicles: Int, val freqPct: Int, val notes: String)

data class WhatIfResult(val simulatedDemand: Int, val occupancyPct: Double, val risk: Risk, val requiredVehicles: Int, val additional: Int)

object Decision {
    fun isPeak(hour: Int) = hour in 7..9 || hour in 17..19

    fun occupancy(ridership: Double, capacity: Double): Pair<Double, Risk> {
        if (capacity <= 0) return 0.0 to Risk.LOW
        val rate = ridership / capacity * 100
        val risk = when {
            rate < 50 -> Risk.LOW
            rate <= 75 -> Risk.MODERATE
            rate <= 90 -> Risk.HIGH
            rate <= 100 -> Risk.CRITICAL
            else -> Risk.OVERCAPACITY
        }
        return Math.round(rate * 10) / 10.0 to risk
    }

    fun allocate(demand: Double, capacity: Double, targetOccupancy: Int = 85, peak: Boolean): Allocation {
        if (capacity <= 0) return Allocation("Operational", 0, 0, "No capacity defined.")
        val effectiveTarget = if (peak) targetOccupancy + 5 else targetOccupancy
        val targetCap = capacity * (effectiveTarget / 100.0)
        val required = if (demand > 0) ceil(demand / targetCap).toInt() else 1
        return when {
            demand > capacity -> {
                val add = max(1, required - 1)
                val freq = min(100, ((demand - capacity) / capacity * 100).toInt())
                val tag = if (peak) " [PEAK WINDOW ACTIVE]" else ""
                Allocation("Deploy Extra Fleet", add, freq, "Demand exceeds standard limit$tag. Deploy approx $add units to stabilize flow.")
            }
            peak && demand > capacity * 0.75 ->
                Allocation("Pre-emptive Peak Frequency Boost", 0, 15, "Peak hour demand is approaching capacity. Pre-emptively increasing frequency by 15%.")
            demand < capacity * 0.35 && !peak ->
                Allocation("Consolidate Fleet", 0, -20, "Low demand corridor. Recommend reducing standard frequency to conserve energy.")
            else -> Allocation("Sufficient Service", 0, 0, "Normal status. Standard operational cycles adequate.")
        }
    }

    fun whatIf(meanRidership: Double, capacity: Double, demandMultPct: Int, targetOcc: Int): WhatIfResult {
        val simulated = (meanRidership * (demandMultPct / 100.0)).toInt()
        val (occ, risk) = occupancy(simulated.toDouble(), capacity)
        val limit = capacity * (targetOcc / 100.0)
        val required = if (simulated > 0) ceil(simulated / limit).toInt() else 1
        return WhatIfResult(simulated, occ, risk, required, max(0, required - 1))
    }
}

// ---------- forecasting with the TFLite model ----------

data class HourForecast(val hour: Int, val demand: Double, val occPct: Double, val risk: Risk)

data class JourneyResult(
    val route: RouteMeta,
    val selected: HourForecast,
    val best: HourForecast,
    val bestIsBetter: Boolean,
)

data class PlanItem(val route: String, val hour: Int, val demand: Int, val allocation: Allocation)

class Forecaster(val meta: Meta, private val model: DemandModel) {

    /** Must match build_x() in tflite_export/train_and_export.py exactly. */
    fun features(route: RouteMeta, hour: Int, dow: Int, weather: String, prevOcc: Double, rollOcc: Double): FloatArray {
        val v = ArrayList<Float>()
        v += sin(2 * PI * hour / 24).toFloat()
        v += cos(2 * PI * hour / 24).toFloat()
        v += sin(2 * PI * dow / 7).toFloat()
        v += cos(2 * PI * dow / 7).toFloat()
        v += if (dow >= 5) 1f else 0f
        v += if (hour in 7..9) 1f else 0f
        v += if (hour in 17..19) 1f else 0f
        v += prevOcc.toFloat()
        v += rollOcc.toFloat()
        meta.routes.forEach { v += if (it.name == route.name) 1f else 0f }
        meta.weathers.forEach { v += if (it == weather) 1f else 0f }
        return v.toFloatArray()
    }

    private fun typicalPrev(r: RouteMeta, hour: Int) = r.hourlyMeanOcc[(hour + 23) % 24]
    private fun typicalRoll(r: RouteMeta, hour: Int) = (1..3).map { r.hourlyMeanOcc[(hour - it + 24) % 24] }.average()

    /** Expected passengers for a route at an hour. [prevDemand] overrides the typical previous-hour load. */
    fun forecast(route: RouteMeta, hour: Int, dow: Int, weather: String = meta.defaultWeather, prevDemand: Double? = null): Double {
        val prevOcc = prevDemand?.let { it / route.capacity } ?: typicalPrev(route, hour)
        val rollOcc = prevDemand?.let { it / route.capacity } ?: typicalRoll(route, hour)
        val occ = model.predictOccupancy(features(route, hour, dow, weather, prevOcc, rollOcc)).coerceAtLeast(0.0)
        return occ * route.capacity
    }

    private fun hourForecast(route: RouteMeta, hour: Int, dow: Int): HourForecast {
        val d = forecast(route, hour, dow)
        val (occ, risk) = Decision.occupancy(d, route.capacity)
        return HourForecast(hour, d, occ, risk)
    }

    fun bestTimes(route: RouteMeta, dow: Int): List<HourForecast> = meta.serviceHours.map { hourForecast(route, it, dow) }

    fun crowdMap(dow: Int): List<Pair<RouteMeta, List<HourForecast>>> = meta.routes.map { it to bestTimes(it, dow) }

    fun journey(from: String, to: String, mode: String, hour: Int, dow: Int): JourneyResult? {
        var routes = if (mode == "All modes") meta.routes else meta.routes.filter { it.mode == mode }
        if (routes.isEmpty()) return null
        val both = routes.filter { from in it.stations && to in it.stations }
        val either = routes.filter { from in it.stations || to in it.stations }
        routes = (both.ifEmpty { either }.ifEmpty { routes }).take(10)
        val route = routes.minByOrNull { hourForecast(it, hour, dow).occPct }!!
        val selected = hourForecast(route, hour, dow)
        val window = (hour - 3..hour + 3).filter { it in meta.serviceHours }.ifEmpty { listOf(hour) }
        val best = window.map { hourForecast(route, it, dow) }.minByOrNull { it.occPct }!!
        return JourneyResult(route, selected, best, best.hour != hour && best.occPct < selected.occPct)
    }

    /** Routes/hours that need a service change on a typical weekday, most severe first. */
    fun fleetPlan(dow: Int = 1, limit: Int = 25): List<PlanItem> =
        meta.routes.flatMap { r ->
            meta.serviceHours.map { h ->
                val d = forecast(r, h, dow)
                PlanItem(r.name, h, d.toInt(), Decision.allocate(d, r.capacity, peak = Decision.isPeak(h)))
            }
        }.filter { it.allocation.addVehicles > 0 || it.allocation.freqPct != 0 }
            .sortedWith(compareByDescending<PlanItem> { it.allocation.addVehicles }.thenByDescending { it.allocation.freqPct })
            .take(limit)
}
