package com.transit.intel

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class Report(val id: String, val time: String, val location: String, val route: String,
                  val type: String, val severity: String, val description: String)

/** Citizen reports are stored on this device only (SharedPreferences). */
class ReportStore(context: Context) {
    private val prefs = context.getSharedPreferences("citizen_reports", Context.MODE_PRIVATE)

    fun add(location: String, route: String, type: String, severity: String, description: String): Report {
        val r = Report(UUID.randomUUID().toString().take(8),
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()), location, route, type, severity, description)
        val arr = JSONArray(prefs.getString("items", "[]"))
        arr.put(JSONObject().put("id", r.id).put("time", r.time).put("location", r.location).put("route", r.route)
            .put("type", r.type).put("severity", r.severity).put("description", r.description))
        prefs.edit().putString("items", arr.toString()).apply()
        return r
    }

    fun all(): List<Report> {
        val arr = JSONArray(prefs.getString("items", "[]"))
        return List(arr.length()) {
            val o = arr.getJSONObject(it)
            Report(o.getString("id"), o.getString("time"), o.getString("location"), o.getString("route"),
                o.getString("type"), o.getString("severity"), o.getString("description"))
        }.reversed()
    }

    fun clear() = prefs.edit().remove("items").apply()
}
