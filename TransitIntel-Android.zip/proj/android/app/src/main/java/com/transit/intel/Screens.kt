package com.transit.intel

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max

private val DAYS = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
private val INK = Color(0xFF102A43)
private val PROBLEMS = listOf("Overcrowding", "Bus unavailable", "Train overcrowded", "Long waiting time",
    "Service delay", "Service cancellation", "Poor station condition", "Accessibility issue", "Other")
private val SEVERITIES = listOf("Low", "Moderate", "High", "Critical")

// ---------- small building blocks ----------

@Composable
private fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content,
    )
}

@Composable
private fun Dropdown(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text(label, fontSize = 12.sp, color = INK)
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selected, modifier = Modifier.weight(1f), textAlign = TextAlign.Start)
                Text("▾")
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { opt ->
                    DropdownMenuItem(text = { Text(opt) }, onClick = { onSelect(opt); expanded = false })
                }
            }
        }
    }
}

@Composable
private fun HourSlider(label: String, hour: Int, onChange: (Int) -> Unit) {
    Column {
        Text("$label: ${"%02d".format(hour)}:00", fontSize = 12.sp, color = INK)
        Slider(value = hour.toFloat(), onValueChange = { onChange(it.toInt()) }, valueRange = 0f..23f, steps = 22)
    }
}

@Composable
private fun InfoCard(accent: Color = INK, content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF4F7FA)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(Modifier.width(5.dp).fillMaxHeight().background(accent))
            Column(Modifier.weight(1f).padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp), content = content)
        }
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE3ECF4)), modifier = modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(label, fontSize = 11.sp, color = INK)
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = INK)
        }
    }
}

@Composable
private fun Sections(titles: List<String>, content: @Composable (Int) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 0.dp) {
            titles.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
        }
        content(tab)
    }
}

private fun pct(v: Double) = "%.1f%%".format(v)

// ---------- app shell ----------

@Composable
fun TransitApp(forecaster: Forecaster, store: ReportStore) {
    var mode by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().background(Color.White)) {
        Column(Modifier.fillMaxWidth().background(INK).padding(16.dp)) {
            Text("AI Transit Intelligence", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Runs fully offline with an on-device TFLite model", color = Color(0xFFD9E2EC), fontSize = 12.sp)
        }
        TabRow(selectedTabIndex = mode) {
            Tab(selected = mode == 0, onClick = { mode = 0 }, text = { Text("Citizen") })
            Tab(selected = mode == 1, onClick = { mode = 1 }, text = { Text("Authority") })
        }
        if (mode == 0) {
            Sections(listOf("Journey", "Best time", "Crowd map", "Report")) { i ->
                when (i) {
                    0 -> JourneyScreen(forecaster)
                    1 -> BestTimeScreen(forecaster)
                    2 -> CrowdMapScreen(forecaster)
                    else -> ReportScreen(forecaster.meta, store)
                }
            }
        } else {
            Sections(listOf("Overview", "Predict", "What-if", "Fleet plan", "Reports")) { i ->
                when (i) {
                    0 -> OverviewScreen(forecaster.meta)
                    1 -> PredictScreen(forecaster)
                    2 -> WhatIfScreen(forecaster.meta)
                    3 -> FleetPlanScreen(forecaster)
                    else -> ReportsListScreen(store)
                }
            }
        }
    }
}

// ---------- citizen ----------

@Composable
private fun JourneyScreen(f: Forecaster) {
    val meta = f.meta
    var from by remember { mutableStateOf(meta.stations.first()) }
    var to by remember { mutableStateOf(meta.stations.getOrElse(1) { meta.stations.first() }) }
    var day by remember { mutableStateOf(DAYS[0]) }
    var hour by remember { mutableIntStateOf(18) }
    var mode by remember { mutableStateOf("All modes") }
    var result by remember { mutableStateOf<JourneyResult?>(null) }
    Page {
        Text("Know the crowd before you travel.", fontWeight = FontWeight.Bold, color = INK)
        Dropdown("From", meta.stations, from) { from = it }
        Dropdown("To", meta.stations, to) { to = it }
        Dropdown("Day", DAYS, day) { day = it }
        HourSlider("Departure hour", hour) { hour = it }
        Dropdown("Transport", meta.modes, mode) { mode = it }
        Button(onClick = { result = f.journey(from, to, mode, hour, DAYS.indexOf(day)) }, modifier = Modifier.fillMaxWidth()) {
            Text("FIND BEST OPTION")
        }
        result?.let { r ->
            if (r.bestIsBetter) {
                InfoCard(Color(r.best.risk.argb)) {
                    Text("⭐ Recommended", fontWeight = FontWeight.Bold, color = INK)
                    Text("${r.route.name} at ${"%02d".format(r.best.hour)}:00", color = INK)
                    Text("${r.best.risk.emoji} ${r.best.risk.label} (${pct(r.best.occPct)} full)", color = INK)
                    Text("≈ ${r.best.demand.toInt()} passengers, capacity ${r.route.capacity.toInt()}", color = INK, fontSize = 12.sp)
                    Text("Least crowded departure within 3 hours of your time.", color = INK, fontSize = 12.sp)
                }
            } else {
                InfoCard(Color(0xFF2E7D32)) {
                    Text("✅ Your time is already the best", fontWeight = FontWeight.Bold, color = INK)
                    Text("No less-crowded departure within 3 hours.", color = INK)
                }
            }
            InfoCard(Color(r.selected.risk.argb)) {
                Text("Your selected departure", fontWeight = FontWeight.Bold, color = INK)
                Text("${r.route.name} at ${"%02d".format(r.selected.hour)}:00", color = INK)
                Text("${r.selected.risk.emoji} ${r.selected.risk.label} (${pct(r.selected.occPct)} full)", color = INK)
                Text("≈ ${r.selected.demand.toInt()} passengers, capacity ${r.route.capacity.toInt()}", color = INK, fontSize = 12.sp)
            }
            if (!meta.metrics.beatsBaseline) Text("⚠️ Model is no better than a simple average; treat forecasts with caution.", color = Color(0xFF9A7B00), fontSize = 12.sp)
        }
        Text("Predictions are estimates from historical demo data, not live transport information.", fontSize = 11.sp, color = Color.Gray)
    }
}

@Composable
private fun BestTimeScreen(f: Forecaster) {
    val meta = f.meta
    var route by remember { mutableStateOf(meta.routes.first().name) }
    var day by remember { mutableStateOf(DAYS[0]) }
    val rows = remember(route, day) { f.bestTimes(meta.route(route), DAYS.indexOf(day)) }
    Page {
        Dropdown("Route / line", meta.routes.map { it.name }, route) { route = it }
        Dropdown("Day", DAYS, day) { day = it }
        rows.forEach {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${"%02d".format(it.hour)}:00", fontWeight = FontWeight.Bold, color = INK, modifier = Modifier.width(60.dp))
                Text("${it.risk.emoji} ${it.risk.label}", color = Color(it.risk.argb), modifier = Modifier.weight(1f))
                Text(pct(it.occPct), color = INK)
            }
        }
        val best = rows.sortedBy { it.occPct }.take(3).sortedBy { it.hour }
        InfoCard(Color(0xFF2E7D32)) {
            Text("⭐ Least crowded hours", fontWeight = FontWeight.Bold, color = INK)
            Text(best.joinToString(", ") { "${"%02d".format(it.hour)}:00 (${it.occPct.toInt()}%)" }, color = INK)
        }
    }
}

@Composable
private fun CrowdMapScreen(f: Forecaster) {
    var day by remember { mutableStateOf(DAYS[0]) }
    val grid = remember(day) { f.crowdMap(DAYS.indexOf(day)) }
    Page {
        Dropdown("Day", DAYS, day) { day = it }
        Text("Predicted occupancy % by route and hour", fontSize = 12.sp, color = INK)
        Column(Modifier.horizontalScroll(rememberScrollState())) {
            Row {
                Spacer(Modifier.width(110.dp))
                f.meta.serviceHours.forEach { Text("%02d".format(it), Modifier.width(36.dp), textAlign = TextAlign.Center, fontSize = 11.sp, color = INK) }
            }
            grid.forEach { (route, cells) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(route.name, Modifier.width(110.dp), fontSize = 11.sp, maxLines = 2, color = INK)
                    cells.forEach { c ->
                        Box(Modifier.size(36.dp).padding(1.dp).background(Color(c.risk.argb)), contentAlignment = Alignment.Center) {
                            Text("${c.occPct.toInt()}", color = Color.White, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
        Text("🟢 <50%  🟡 50–75%  🟠 75–90%  🔴 >90%", fontSize = 12.sp, color = INK)
    }
}

@Composable
private fun ReportScreen(meta: Meta, store: ReportStore) {
    var location by remember { mutableStateOf("") }
    var route by remember { mutableStateOf(meta.routes.first().name) }
    var type by remember { mutableStateOf(PROBLEMS[0]) }
    var severity by remember { mutableStateOf("High") }
    var description by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    Page {
        Text("Report a crowding or service problem", fontWeight = FontWeight.Bold, color = INK)
        OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Location / station") }, modifier = Modifier.fillMaxWidth())
        Dropdown("Route", meta.routes.map { it.name }, route) { route = it }
        Dropdown("Problem type", PROBLEMS, type) { type = it }
        Dropdown("Severity", SEVERITIES, severity) { severity = it }
        OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            val r = store.add(location.ifBlank { "Unspecified" }, route, type, severity, description)
            status = "Thank you! Report ${r.id} saved on this device."
            description = ""
        }, modifier = Modifier.fillMaxWidth()) { Text("SUBMIT REPORT") }
        if (status.isNotEmpty()) Text(status, color = Color(0xFF2E7D32))
    }
}

// ---------- authority ----------

@Composable
private fun OverviewScreen(meta: Meta) {
    val k = meta.kpis
    val m = meta.metrics
    Page {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat("Total ridership", "%,d".format(k.totalRidership), Modifier.weight(1f))
            Stat("Avg per record", "${k.avgRidership}", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat("Peak hour", "%02d:00".format(k.peakHour), Modifier.weight(1f))
            Stat("Over capacity", "${k.overcapacityRecords}", Modifier.weight(1f))
        }
        Stat("Highest-demand route", k.topRoute, Modifier.fillMaxWidth())
        Stat("Busiest station", k.busiestStation, Modifier.fillMaxWidth())
        InfoCard {
            Text("Model quality (held-out future data)", fontWeight = FontWeight.Bold, color = INK)
            Text("Model error: ${"%.1f".format(m.modelMae)} passengers (MAE)", color = INK)
            Text("Baseline error: ${"%.1f".format(m.baselineMae)} passengers", color = INK)
            Text("R²: ${"%.3f".format(m.modelR2)}", color = INK)
            Text(if (m.beatsBaseline) "✅ Beats the simple-average baseline" else "⚠️ Does not beat the baseline", color = INK)
            Text("Trained on ${"%,d".format(k.records)} records. To use new data, retrain with tflite_export/train_and_export.py and rebuild.", fontSize = 11.sp, color = INK)
        }
    }
}

@Composable
private fun PredictScreen(f: Forecaster) {
    val meta = f.meta
    var route by remember { mutableStateOf(meta.routes.first().name) }
    var day by remember { mutableStateOf(DAYS[0]) }
    var hour by remember { mutableIntStateOf(18) }
    var weather by remember { mutableStateOf(meta.defaultWeather) }
    var prev by remember { mutableStateOf("") }
    var out by remember { mutableStateOf<List<String>?>(null) }
    Page {
        Dropdown("Route", meta.routes.map { it.name }, route) { route = it }
        Dropdown("Weekday", DAYS, day) { day = it }
        HourSlider("Hour", hour) { hour = it }
        Dropdown("Weather", meta.weathers, weather) { weather = it }
        OutlinedTextField(value = prev, onValueChange = { prev = it.filter { c -> c.isDigit() || c == '.' } },
            label = { Text("Previous-hour demand (optional)") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            val r = meta.route(route)
            val d = f.forecast(r, hour, DAYS.indexOf(day), weather, prev.toDoubleOrNull())
            val res = max(5.0, meta.rmseOcc * r.capacity)
            val (occ, risk) = Decision.occupancy(d, r.capacity)
            val a = Decision.allocate(d, r.capacity, peak = Decision.isPeak(hour))
            out = listOf(
                "Expected ridership: ${d.toInt()}",
                "≈95% range: ${max(0, (d - 1.96 * res).toInt())} to ${(d + 1.96 * res).toInt()}",
                "Occupancy: ${pct(occ)} ${risk.emoji} ${risk.label}",
                "Status: ${a.status}",
                "Fleet adjustment: +${a.addVehicles} vehicles",
                "Frequency change: ${a.freqPct}%",
                a.notes,
            )
        }, modifier = Modifier.fillMaxWidth()) { Text("ANALYZE") }
        out?.let { lines -> InfoCard { lines.forEach { Text(it, color = INK) } } }
    }
}

@Composable
private fun WhatIfScreen(meta: Meta) {
    var capacity by remember { mutableFloatStateOf(150f) }
    var mult by remember { mutableFloatStateOf(120f) }
    var target by remember { mutableFloatStateOf(85f) }
    val r = Decision.whatIf(meta.meanRidership, capacity.toDouble(), mult.toInt(), target.toInt())
    Page {
        Text("Vehicle capacity: ${capacity.toInt()}", color = INK, fontSize = 12.sp)
        Slider(value = capacity, onValueChange = { capacity = (it / 10).toInt() * 10f }, valueRange = 10f..1000f)
        Text("Ridership load: ${mult.toInt()}% of normal", color = INK, fontSize = 12.sp)
        Slider(value = mult, onValueChange = { mult = (it / 10).toInt() * 10f }, valueRange = 10f..300f)
        Text("Target occupancy limit: ${target.toInt()}%", color = INK, fontSize = 12.sp)
        Slider(value = target, onValueChange = { target = (it / 5).toInt() * 5f }, valueRange = 50f..100f)
        InfoCard(Color(r.risk.argb)) {
            Text("Scenario results", fontWeight = FontWeight.Bold, color = INK)
            Text("Simulated ridership: ${r.simulatedDemand}", color = INK)
            Text("Occupancy: ${pct(r.occupancyPct)} ${r.risk.emoji} ${r.risk.label}", color = INK)
            Text("Vehicles needed: ${r.requiredVehicles} (+${r.additional} additional)", color = INK)
        }
    }
}

@Composable
private fun FleetPlanScreen(f: Forecaster) {
    val plan = remember { f.fleetPlan() }
    Page {
        Text("Typical-weekday service changes suggested by the model (most urgent first)", fontSize = 12.sp, color = INK)
        if (plan.isEmpty()) Text("No adjustments required.", color = INK)
        plan.forEach {
            InfoCard(if (it.allocation.addVehicles > 0) Color(0xFFC62828) else Color(0xFFE65100)) {
                Text("${it.route} · ${"%02d".format(it.hour)}:00", fontWeight = FontWeight.Bold, color = INK)
                Text("Demand ≈ ${it.demand} · ${it.allocation.status}", color = INK, fontSize = 13.sp)
                Text("+${it.allocation.addVehicles} vehicles, frequency ${it.allocation.freqPct}%", color = INK, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun ReportsListScreen(store: ReportStore) {
    var reports by remember { mutableStateOf(store.all()) }
    Page {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { reports = store.all() }) { Text("Refresh") }
            OutlinedButton(onClick = { store.clear(); reports = store.all() }) { Text("Clear all") }
        }
        val critical = reports.count { it.severity == "Critical" }
        val common = reports.groupingBy { it.type }.eachCount().maxByOrNull { it.value }?.key ?: "N/A"
        Text("Total: ${reports.size} · Critical: $critical · Most common: $common", color = INK, fontWeight = FontWeight.Bold)
        if (reports.isEmpty()) Text("No reports yet. Submit one from Citizen mode.", color = INK)
        reports.forEach {
            InfoCard {
                Text("${it.type} · ${it.severity}", fontWeight = FontWeight.Bold, color = INK)
                Text("${it.route} @ ${it.location}", color = INK, fontSize = 13.sp)
                if (it.description.isNotBlank()) Text(it.description, color = INK, fontSize = 13.sp)
                Text("${it.time} · #${it.id}", color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}
