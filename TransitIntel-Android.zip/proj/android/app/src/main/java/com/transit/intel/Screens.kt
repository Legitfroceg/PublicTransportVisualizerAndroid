package com.transit.intel

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val DAYS = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
private val INK = Color(0xFF102A43)
private val PROBLEMS = listOf("Overcrowding", "Train delayed", "Missed connection", "Long waiting time",
    "Service cancellation", "Poor station condition", "Accessibility issue", "Other")
private val SEVERITIES = listOf("Low", "Moderate", "High", "Critical")

private fun hm(hour: Int) = "%02d:00".format(hour)
private fun one(v: Double) = "%.1f".format(v)

// ---------- small building blocks ----------

@Composable
private fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content,
    )
}

@Composable
private fun Dropdown(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text(label, fontSize = 12.sp, color = INK)
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selected, modifier = Modifier.weight(1f), textAlign = TextAlign.Start)
                Text("▾")
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { opt ->
                    DropdownMenuItem(text = { Text(opt) }, onClick = { onSelect(opt); expanded = false })
                }
            }
        }
    }
}

@Composable
private fun HourSlider(label: String, hour: Int, onChange: (Int) -> Unit) {
    Column {
        Text("$label: ${hm(hour)}", fontSize = 12.sp, color = INK)
        Slider(value = hour.toFloat(), onValueChange = { onChange(it.toInt()) }, valueRange = 0f..23f, steps = 22)
    }
}

@Composable
private fun InfoCard(accent: Color = INK, content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF4F7FA)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(Modifier.width(5.dp).fillMaxHeight().background(accent))
            Column(Modifier.weight(1f).padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp), content = content)
        }
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE3ECF4)), modifier = modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(label, fontSize = 11.sp, color = INK)
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = INK)
        }
    }
}

@Composable
private fun Sections(titles: List<String>, content: @Composable (Int) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 0.dp) {
            titles.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
        }
        content(tab)
    }
}

// ---------- app shell ----------

@Composable
fun TransitApp(forecaster: Forecaster, store: ReportStore) {
    var mode by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().background(Color.White)) {
        Column(Modifier.fillMaxWidth().background(INK).padding(16.dp)) {
            Text("${forecaster.meta.city} Suburban Rail Intelligence", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Offline delay & crowding forecasts from an on-device TFLite model", color = Color(0xFFD9E2EC), fontSize = 12.sp)
        }
        TabRow(selectedTabIndex = mode) {
            Tab(selected = mode == 0, onClick = { mode = 0 }, text = { Text("Citizen") })
            Tab(selected = mode == 1, onClick = { mode = 1 }, text = { Text("Authority") })
        }
        if (mode == 0) {
            Sections(listOf("Forecast", "Best time", "Delay map", "Report")) { i ->
                when (i) {
                    0 -> ForecastScreen(forecaster)
                    1 -> BestTimeScreen(forecaster)
                    2 -> DelayMapScreen(forecaster)
                    else -> ReportScreen(forecaster.meta, store)
                }
            }
        } else {
            Sections(listOf("Overview", "Predict", "What-if", "Watch list", "Reports")) { i ->
                when (i) {
                    0 -> OverviewScreen(forecaster)
                    1 -> PredictScreen(forecaster)
                    2 -> WhatIfScreen(forecaster)
                    3 -> WatchListScreen(forecaster)
                    else -> ReportsListScreen(store)
                }
            }
        }
    }
}

// ---------- citizen ----------

@Composable
private fun ForecastScreen(f: Forecaster) {
    val meta = f.meta
    var line by remember { mutableStateOf(meta.lines.first()) }
    var station by remember { mutableStateOf(meta.stations.first()) }
    var type by remember { mutableStateOf(meta.transitTypes.first()) }
    var weather by remember { mutableStateOf(meta.weatherConditions.first()) }
    var day by remember { mutableStateOf(DAYS[0]) }
    var hour by remember { mutableIntStateOf(9) }
    var result by remember { mutableStateOf<DelayForecast?>(null) }
    val dow = DAYS.indexOf(day)
    Page {
        Text("Forecast your commute before you leave.", fontWeight = FontWeight.Bold, color = INK)
        Dropdown("Line", meta.lines, line) { line = it }
        Dropdown("Station", meta.stations, station) { station = it }
        Dropdown("Commute type", meta.transitTypes, type) { type = it }
        Dropdown("Weather", meta.weatherConditions, weather) { weather = it }
        Dropdown("Day", DAYS, day) { day = it }
        HourSlider("Departure hour", hour) { hour = it }
        Button(onClick = { result = f.forecast(line, station, type, weather, hour, dow) }, modifier = Modifier.fillMaxWidth()) {
            Text("CHECK MY TRAIN")
        }
        result?.let { r ->
            InfoCard(Color(r.risk.argb)) {
                Text("$type · $line", fontWeight = FontWeight.Bold, color = INK)
                Text("$station at ${hm(r.hour)}", color = INK)
                Text("${r.risk.emoji} ${one(r.delayMins)} min delay · ${r.risk.label}", color = INK)
                Text("Crowding: ${r.crowd.label}", color = INK)
            }
            val best = f.compareTypes(line, station, weather, hour, dow).minByOrNull { it.forecast.delayMins }
            best?.let { b ->
                InfoCard(Color(0xFF2E7D32)) {
                    Text("⭐ Least delayed commute type", fontWeight = FontWeight.Bold, color = INK)
                    Text("${b.type} — ${one(b.forecast.delayMins)} min at ${hm(hour)}", color = INK)
                }
            }
        }
        Text("Estimates from an offline model trained on historical patterns, not live train information.", fontSize = 11.sp, color = Color.Gray)
    }
}

@Composable
private fun BestTimeScreen(f: Forecaster) {
    val meta = f.meta
    var line by remember { mutableStateOf(meta.lines.first()) }
    var station by remember { mutableStateOf(meta.stations.first()) }
    var type by remember { mutableStateOf(meta.transitTypes.first()) }
    var weather by remember { mutableStateOf(meta.weatherConditions.first()) }
    var day by remember { mutableStateOf(DAYS[0]) }
    val rows = remember(line, station, type, weather, day) {
        f.dayForecast(line, station, type, weather, DAYS.indexOf(day))
    }
    Page {
        Dropdown("Line", meta.lines, line) { line = it }
        Dropdown("Station", meta.stations, station) { station = it }
        Dropdown("Commute type", meta.transitTypes, type) { type = it }
        Dropdown("Weather", meta.weatherConditions, weather) { weather = it }
        Dropdown("Day", DAYS, day) { day = it }
        Text("Predicted delay through the day", fontSize = 12.sp, color = INK)
        rows.forEach { r ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(hm(r.hour), fontWeight = FontWeight.Bold, color = INK, modifier = Modifier.width(60.dp))
                Text("${r.risk.emoji} ${r.crowd.label}", color = Color(r.risk.argb), modifier = Modifier.weight(1f), fontSize = 13.sp, maxLines = 1)
                Text("${one(r.delayMins)} min", color = INK)
            }
        }
        val best = rows.sortedBy { it.delayMins }.take(3).sortedBy { it.hour }
        InfoCard(Color(0xFF2E7D32)) {
            Text("⭐ Least delayed hours", fontWeight = FontWeight.Bold, color = INK)
            Text(best.joinToString(", ") { "${hm(it.hour)} (${it.delayMins.toInt()} min)" }, color = INK)
        }
    }
}

@Composable
private fun DelayMapScreen(f: Forecaster) {
    val meta = f.meta
    var station by remember { mutableStateOf(meta.stations.first()) }
    var type by remember { mutableStateOf(meta.transitTypes.first()) }
    var weather by remember { mutableStateOf(meta.weatherConditions.first()) }
    var day by remember { mutableStateOf(DAYS[0]) }
    val dow = DAYS.indexOf(day)
    val grid = remember(station, type, weather, day) {
        meta.lines.map { line -> line to f.dayForecast(line, station, type, weather, dow) }
    }
    Page {
        Dropdown("Station", meta.stations, station) { station = it }
        Dropdown("Commute type", meta.transitTypes, type) { type = it }
        Dropdown("Weather", meta.weatherConditions, weather) { weather = it }
        Dropdown("Day", DAYS, day) { day = it }
        Text("Predicted delay (minutes) by line and hour", fontSize = 12.sp, color = INK)
        Column(Modifier.horizontalScroll(rememberScrollState())) {
            Row {
                Spacer(Modifier.width(110.dp))
                SERVICE_HOURS.forEach { Text("%02d".format(it), Modifier.width(40.dp), textAlign = TextAlign.Center, fontSize = 11.sp, color = INK) }
            }
            grid.forEach { (line, cells) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(line, Modifier.width(110.dp), fontSize = 11.sp, maxLines = 2, color = INK)
                    cells.forEach { c ->
                        Box(Modifier.size(40.dp).padding(1.dp).background(Color(c.risk.argb)), contentAlignment = Alignment.Center) {
                            Text("${c.delayMins.toInt()}", color = Color.White, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
        Text("🟢 <5 min  🟡 5–15  🟠 15–30  🔴 >30 min delay", fontSize = 12.sp, color = INK)
    }
}

@Composable
private fun ReportScreen(meta: TransitMeta, store: ReportStore) {
    var station by remember { mutableStateOf(meta.stations.first()) }
    var line by remember { mutableStateOf(meta.lines.first()) }
    var type by remember { mutableStateOf(PROBLEMS[0]) }
    var severity by remember { mutableStateOf("High") }
    var description by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    Page {
        Text("Report a crowding or service problem", fontWeight = FontWeight.Bold, color = INK)
        Dropdown("Station", meta.stations, station) { station = it }
        Dropdown("Line", meta.lines, line) { line = it }
        Dropdown("Problem type", PROBLEMS, type) { type = it }
        Dropdown("Severity", SEVERITIES, severity) { severity = it }
        OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            val r = store.add(station.ifBlank { "Unspecified" }, line, type, severity, description)
            status = "Thank you! Report ${r.id} saved on this device."
            description = ""
        }, modifier = Modifier.fillMaxWidth()) { Text("SUBMIT REPORT") }
        if (status.isNotEmpty()) Text(status, color = Color(0xFF2E7D32))
    }
}

// ---------- authority ----------

@Composable
private fun OverviewScreen(f: Forecaster) {
    val meta = f.meta
    val worst = meta.lines.map { line ->
        line to f.forecast(line, meta.stations.first(), meta.transitTypes.first(), meta.weatherConditions.last(), 18, 1)
    }.maxByOrNull { it.second.delayMins }
    Page {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat("Lines", "${meta.lines.size}", Modifier.weight(1f))
            Stat("Stations", "${meta.stations.size}", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat("Commute types", "${meta.transitTypes.size}", Modifier.weight(1f))
            Stat("Weather states", "${meta.weatherConditions.size}", Modifier.weight(1f))
        }
        InfoCard {
            Text("Network", fontWeight = FontWeight.Bold, color = INK)
            Text(meta.lines.joinToString(", "), color = INK, fontSize = 12.sp)
            Text("Peak windows ${hm(Rules.MORNING_PEAK.first)}–${hm(Rules.MORNING_PEAK.last)} and ${hm(Rules.EVENING_PEAK.first)}–${hm(Rules.EVENING_PEAK.last)}", color = INK, fontSize = 12.sp)
            Text("Sundays add a mega-block maintenance penalty.", color = INK, fontSize = 12.sp)
        }
        worst?.let { (line, fc) ->
            InfoCard(Color(fc.risk.argb)) {
                Text("Highest delay in the evening peak", fontWeight = FontWeight.Bold, color = INK)
                Text("$line · ${fc.risk.emoji} ${one(fc.delayMins)} min (${meta.weatherConditions.last()})", color = INK)
            }
        }
    }
}

@Composable
private fun PredictScreen(f: Forecaster) {
    val meta = f.meta
    var line by remember { mutableStateOf(meta.lines.first()) }
    var station by remember { mutableStateOf(meta.stations.first()) }
    var type by remember { mutableStateOf(meta.transitTypes.first()) }
    var weather by remember { mutableStateOf(meta.weatherConditions.first()) }
    var day by remember { mutableStateOf(DAYS[0]) }
    var hour by remember { mutableIntStateOf(18) }
    var out by remember { mutableStateOf<List<String>?>(null) }
    val dow = DAYS.indexOf(day)
    Page {
        Dropdown("Line", meta.lines, line) { line = it }
        Dropdown("Station", meta.stations, station) { station = it }
        Dropdown("Commute type", meta.transitTypes, type) { type = it }
        Dropdown("Weather", meta.weatherConditions, weather) { weather = it }
        Dropdown("Day", DAYS, day) { day = it }
        HourSlider("Hour", hour) { hour = it }
        Button(onClick = {
            val fc = f.forecast(line, station, type, weather, hour, dow)
            out = listOf(
                "Line: $line",
                "Station: $station",
                "Commute type: $type",
                "Weather: $weather",
                "Day/hour: ${DAYS[dow]} ${hm(hour)}",
                "Predicted delay: ${one(fc.delayMins)} min",
                "Risk: ${fc.risk.emoji} ${fc.risk.label}",
                "Crowding: ${fc.crowd.label}",
                "Peak window: ${if (Rules.isPeak(hour)) "yes" else "no"}",
                "Sunday mega block: ${if (Rules.isMegaBlock(dow)) "yes" else "no"}",
            )
        }, modifier = Modifier.fillMaxWidth()) { Text("ANALYZE") }
        out?.let { lines -> InfoCard { lines.forEach { Text(it, color = INK) } } }
    }
}

@Composable
private fun WhatIfScreen(f: Forecaster) {
    val meta = f.meta
    var line by remember { mutableStateOf(meta.lines.first()) }
    var station by remember { mutableStateOf(meta.stations.first()) }
    var type by remember { mutableStateOf(meta.transitTypes.first()) }
    var day by remember { mutableStateOf(DAYS[0]) }
    var hour by remember { mutableIntStateOf(18) }
    val scenarios = f.weatherScenarios(line, station, type, hour, DAYS.indexOf(day))
    Page {
        Text("Weather impact on a single trip", fontWeight = FontWeight.Bold, color = INK)
        Dropdown("Line", meta.lines, line) { line = it }
        Dropdown("Station", meta.stations, station) { station = it }
        Dropdown("Commute type", meta.transitTypes, type) { type = it }
        Dropdown("Day", DAYS, day) { day = it }
        HourSlider("Hour", hour) { hour = it }
        scenarios.forEach { s ->
            InfoCard(Color(s.risk.argb)) {
                Text(s.weather, fontWeight = FontWeight.Bold, color = INK)
                Text("${s.risk.emoji} ${one(s.delayMins)} min (${s.risk.label})", color = INK)
            }
        }
    }
}

@Composable
private fun WatchListScreen(f: Forecaster) {
    val meta = f.meta
    var type by remember { mutableStateOf(meta.transitTypes.first()) }
    var weather by remember { mutableStateOf(meta.weatherConditions.last()) }
    val station = meta.stations.first()
    val plan = remember(type, weather) {
        meta.lines.flatMap { line ->
            SERVICE_HOURS.map { h -> line to f.forecast(line, station, type, weather, h, 1) }
        }.filter { it.second.risk >= DelayRisk.MODERATE }
            .sortedByDescending { it.second.delayMins }
            .take(25)
    }
    Page {
        Text("Typical-weekday service watch list (most delayed first)", fontSize = 12.sp, color = INK)
        Dropdown("Commute type", meta.transitTypes, type) { type = it }
        Dropdown("Weather", meta.weatherConditions, weather) { weather = it }
        if (plan.isEmpty()) Text("No significant delays predicted.", color = INK)
        plan.forEach { (line, fc) ->
            InfoCard(Color(fc.risk.argb)) {
                Text("$line · ${hm(fc.hour)}", fontWeight = FontWeight.Bold, color = INK)
                Text("${fc.risk.emoji} ${one(fc.delayMins)} min (${fc.risk.label})", color = INK, fontSize = 13.sp)
                Text("Crowding: ${fc.crowd.label}", color = INK, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun ReportsListScreen(store: ReportStore) {
    var reports by remember { mutableStateOf(store.all()) }
    Page {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { reports = store.all() }) { Text("Refresh") }
            OutlinedButton(onClick = { store.clear(); reports = store.all() }) { Text("Clear all") }
        }
        val critical = reports.count { it.severity == "Critical" }
        val common = reports.groupingBy { it.type }.eachCount().maxByOrNull { it.value }?.key ?: "N/A"
        Text("Total: ${reports.size} · Critical: $critical · Most common: $common", color = INK, fontWeight = FontWeight.Bold)
        if (reports.isEmpty()) Text("No reports yet. Submit one from Citizen mode.", color = INK)
        reports.forEach {
            InfoCard {
                Text("${it.type} · ${it.severity}", fontWeight = FontWeight.Bold, color = INK)
                Text("${it.route} @ ${it.location}", color = INK, fontSize = 13.sp)
                if (it.description.isNotBlank()) Text(it.description, color = INK, fontSize = 13.sp)
                Text("${it.time} · #${it.id}", color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}
