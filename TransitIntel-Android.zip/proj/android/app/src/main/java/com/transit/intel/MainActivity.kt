package com.transit.intel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // Always light theme: the UI uses fixed dark-on-light colours, so it stays readable on phones in dark mode
            MaterialTheme(colorScheme = lightColorScheme()) {
                Surface {
                    val loaded = remember {
                        runCatching { Forecaster(MetaLoader.load(this@MainActivity), TfliteModel(this@MainActivity)) }
                    }
                    val store = remember { ReportStore(this@MainActivity) }
                    loaded.fold(
                        onSuccess = { TransitApp(it, store) },
                        onFailure = { Column(Modifier.padding(24.dp)) { Text("Could not load the model: ${it.message}") } },
                    )
                }
            }
        }
    }
}
