package com.transit.intel

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import org.tensorflow.lite.Interpreter

private fun JSONArray.strings(): List<String> = List(length()) { getString(it) }

object MetaLoader {
    fun load(context: Context): TransitMeta {
        val o = JSONObject(context.assets.open("transit_meta.json").bufferedReader().use { it.readText() })
        return TransitMeta(
            version = o.optString("version", "1.0.0"),
            city = o.optString("city", "Mumbai"),
            lines = o.getJSONArray("lines").strings(),
            stations = o.getJSONArray("stations").strings(),
            transitTypes = o.getJSONArray("transit_types").strings(),
            crowdLabels = o.getJSONArray("crowd_labels").strings(),
            weatherConditions = o.getJSONArray("weather_conditions").strings(),
        )
    }
}

/** Runs assets/transit_model.tflite on-device with the TensorFlow Lite interpreter. No network needed. */
class TfliteModel(context: Context) : DelayModel {
    private val interpreter: Interpreter

    init {
        val bytes = context.assets.open("transit_model.tflite").use { it.readBytes() }
        val buffer = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
        buffer.put(bytes)
        buffer.rewind()
        interpreter = Interpreter(buffer)
    }

    override fun predictDelay(features: FloatArray): Double {
        val output = Array(1) { FloatArray(1) }
        interpreter.run(arrayOf(features), output)
        return output[0][0].toDouble()
    }
}
