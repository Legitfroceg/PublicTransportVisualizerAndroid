package com.transit.intel

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import org.tensorflow.lite.Interpreter

private fun JSONArray.strings(): List<String> = List(length()) { getString(it) }
private fun JSONArray.doubles(): List<Double> = List(length()) { getDouble(it) }
private fun JSONArray.ints(): List<Int> = List(length()) { getInt(it) }

object MetaLoader {
    fun load(context: Context): Meta {
        val o = JSONObject(context.assets.open("transit_meta.json").bufferedReader().use { it.readText() })
        val routes = o.getJSONArray("routes").let { arr ->
            List(arr.length()) {
                val r = arr.getJSONObject(it)
                RouteMeta(r.getString("name"), r.getString("mode"), r.getDouble("capacity"),
                    r.getJSONArray("stations").strings(), r.getJSONArray("hourly_mean_occ").doubles())
            }
        }
        val m = o.getJSONObject("metrics")
        val k = o.getJSONObject("kpis")
        return Meta(
            routes = routes,
            weathers = o.getJSONArray("weathers").strings(),
            defaultWeather = o.getString("default_weather"),
            serviceHours = o.getJSONArray("service_hours").ints(),
            rmseOcc = o.getDouble("rmse_occ"),
            meanRidership = o.getDouble("mean_ridership"),
            metrics = ModelMetrics(m.getDouble("model_mae"), m.getDouble("model_r2"), m.getDouble("baseline_mae"), m.getBoolean("beats_baseline")),
            kpis = Kpis(k.getInt("records"), k.getLong("total_ridership"), k.getInt("avg_ridership"), k.getInt("peak_hour"),
                k.getString("top_route"), k.getString("busiest_station"), k.getInt("overcapacity_records")),
        )
    }
}

/** Runs assets/transit_model.tflite on-device with the TensorFlow Lite interpreter. No network needed. */
class TfliteModel(context: Context) : DemandModel {
    private val interpreter: Interpreter

    init {
        val bytes = context.assets.open("transit_model.tflite").use { it.readBytes() }
        val buffer = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
        buffer.put(bytes)
        buffer.rewind()
        interpreter = Interpreter(buffer)
    }

    override fun predictOccupancy(features: FloatArray): Double {
        val output = Array(1) { FloatArray(1) }
        interpreter.run(arrayOf(features), output)
        return output[0][0].toDouble()
    }
}
