#!/usr/bin/env python3
"""Train a small neural network on transit data and export it for the Android app.

Writes two files (default: ../android/app/src/main/assets):
  transit_model.tflite  - the on-device model (predicts occupancy = ridership / capacity)
  transit_meta.json     - routes, capacities, typical hourly load, KPIs and model quality

Usage:
  python train_and_export.py                     # synthetic demo data
  python train_and_export.py --csv my_data.csv   # your own data

CSV columns (case-insensitive). Required: a timestamp WITH time of day, a route, a ridership count.
Optional: capacity, station, mode, weather. See ALIASES for accepted column names.
"""
import argparse
import json
import os
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
import tensorflow as tf

SEED = 42
ALIASES = {
    "timestamp": ["timestamp", "datetime", "date", "time"],
    "route": ["route", "route_id", "line", "line_id", "service", "service_route"],
    "ridership": ["ridership", "passengers", "passenger_count", "boardings", "demand", "trips", "entries"],
    "capacity": ["capacity", "vehicle_capacity", "seats", "max_capacity"],
    "station": ["station", "station_name", "stop", "stop_name", "station_stop"],
    "mode": ["mode", "transport_mode", "vehicle_type", "transport_type"],
    "weather": ["weather", "weather_condition"],
}


def generate_demo_dataset(num_days=45):
    """Synthetic network with morning/evening peaks, weekends and weather (same logic as the web app)."""
    rng = np.random.default_rng(SEED)
    routes = {
        "Route 101 (Metro-Link)": ("Train", 500, ["Central Station", "Tech Park", "West Terminal"]),
        "Route 205 (Downtown Express)": ("Bus", 80, ["North Gate", "Financial District", "Central Station"]),
        "Route 42 (Suburban Shuttle)": ("Bus", 50, ["Suburban Mall", "Green Valley", "Central Station"]),
    }
    start = datetime(2026, 8, 1)
    rows = []
    for day in range(num_days):
        date = start + timedelta(days=day)
        weekend = date.weekday() >= 5
        weather = rng.choice(["Clear", "Rainy", "Overcast"], p=[0.7, 0.2, 0.1])
        for route, (mode, cap, stations) in routes.items():
            for station in stations:
                for hour in range(6, 24):
                    if weekend:
                        base = cap * 0.7 if 11 <= hour <= 16 else cap * 0.25
                    elif 7 <= hour <= 9:
                        base = cap * 1.15
                    elif 17 <= hour <= 19:
                        base = cap * 1.25
                    elif 11 <= hour <= 14:
                        base = cap * 0.5
                    else:
                        base = cap * 0.15
                    factor = 0.85 if weather == "Rainy" else 1.0
                    ridership = max(0, int(base * factor + rng.normal(0, cap * 0.08)))
                    rows.append({"timestamp": date.replace(hour=hour), "route": route, "station": station,
                                 "mode": mode, "ridership": ridership, "capacity": cap, "weather": weather})
    return pd.DataFrame(rows)


def load_csv(path):
    raw = pd.read_csv(path)
    lower = {c.lower().strip(): c for c in raw.columns}
    df = pd.DataFrame()
    for key, names in ALIASES.items():
        col = next((lower[n] for n in names if n in lower), None)
        if col is not None:
            df[key] = raw[col]
    missing = [k for k in ("timestamp", "route", "ridership") if k not in df]
    if missing:
        raise SystemExit(f"CSV is missing required column(s) {missing}. Columns found: {list(raw.columns)}")
    if "capacity" not in df:
        print("WARNING: no capacity column; assuming capacity 100 per vehicle")
        df["capacity"] = 100
    for key, default in (("station", "Main stop"), ("mode", "Transit"), ("weather", "Clear")):
        if key not in df:
            df[key] = default
    return df


def prepare(df):
    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df = df.dropna(subset=["timestamp"])
    df["ridership"] = pd.to_numeric(df["ridership"], errors="coerce").fillna(0).clip(lower=0)
    df["capacity"] = pd.to_numeric(df["capacity"], errors="coerce").fillna(100).clip(lower=1)
    for c in ("route", "station", "mode", "weather"):
        df[c] = df[c].fillna("Unknown").astype(str)
    if len(df) < 200:
        raise SystemExit("Need at least 200 valid rows to train.")
    if df["timestamp"].dt.hour.nunique() <= 1:
        print("WARNING: no time-of-day information; hourly forecasts will not be meaningful.")
    df = df.sort_values("timestamp", kind="mergesort").reset_index(drop=True)
    df["hour"] = df["timestamp"].dt.hour
    df["dow"] = df["timestamp"].dt.dayofweek
    df["occupancy"] = df["ridership"] / df["capacity"]
    # Lags per route + station, so a row only sees that stop's own earlier hours (no leakage)
    grp = df.groupby(["route", "station"])["occupancy"]
    mean_occ = df["occupancy"].mean()
    df["prev_occ"] = grp.shift(1).fillna(mean_occ)
    df["roll_occ"] = grp.transform(lambda s: s.shift(1).rolling(3, min_periods=1).mean()).fillna(mean_occ)
    return df


def feature_names(routes, weathers):
    return (["hour_sin", "hour_cos", "dow_sin", "dow_cos", "weekend", "morning_peak", "evening_peak",
             "prev_occ", "roll_occ"] + [f"route={r}" for r in routes] + [f"weather={w}" for w in weathers])


def build_x(df, routes, weathers):
    h, d = df["hour"].to_numpy(), df["dow"].to_numpy()
    cols = [np.sin(2 * np.pi * h / 24), np.cos(2 * np.pi * h / 24),
            np.sin(2 * np.pi * d / 7), np.cos(2 * np.pi * d / 7),
            (d >= 5).astype(float), ((h >= 7) & (h <= 9)).astype(float), ((h >= 17) & (h <= 19)).astype(float),
            df["prev_occ"].to_numpy(), df["roll_occ"].to_numpy()]
    cols += [(df["route"] == r).to_numpy().astype(float) for r in routes]
    cols += [(df["weather"] == w).to_numpy().astype(float) for w in weathers]
    return np.column_stack(cols).astype("float32")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", help="path to your own dataset (default: synthetic demo data)")
    ap.add_argument("--out", default=os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                  "..", "android", "app", "src", "main", "assets"))
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    tf.keras.utils.set_random_seed(SEED)

    df = prepare(load_csv(args.csv) if args.csv else generate_demo_dataset())
    routes = sorted(df["route"].unique())
    weathers = sorted(df["weather"].unique())
    names = feature_names(routes, weathers)
    X, y = build_x(df, routes, weathers), df["occupancy"].to_numpy().astype("float32")

    split = int(len(df) * 0.8)  # time-aware split: train on the past, test on the future
    Xtr, Xte, ytr, yte = X[:split], X[split:], y[:split], y[split:]

    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(X.shape[1],)),
        tf.keras.layers.Dense(64, activation="relu"),
        tf.keras.layers.Dense(32, activation="relu"),
        tf.keras.layers.Dense(1),
    ])
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3), loss="mse")
    model.fit(Xtr, ytr, validation_split=0.1, epochs=200, batch_size=64, verbose=0,
              callbacks=[tf.keras.callbacks.EarlyStopping(patience=15, restore_best_weights=True)])

    # Evaluate in passengers (occupancy x capacity), against a "predict the average" baseline
    cap_te = df["capacity"].to_numpy()[split:]
    pred_occ = np.clip(model.predict(Xte, verbose=0).ravel(), 0, None)
    actual, pred = yte * cap_te, pred_occ * cap_te
    base = np.full_like(actual, (ytr * df["capacity"].to_numpy()[:split]).mean())
    mae, base_mae = float(np.mean(np.abs(actual - pred))), float(np.mean(np.abs(actual - base)))
    r2 = float(1 - np.sum((actual - pred) ** 2) / np.sum((actual - actual.mean()) ** 2))
    rmse_occ = float(np.sqrt(np.mean((yte - pred_occ) ** 2)))
    print(f"Test MAE {mae:.1f} passengers | baseline MAE {base_mae:.1f} | R2 {r2:.3f}")

    # Export to TFLite and verify the .tflite file reproduces the Keras model
    # Export via a SavedModel: more reliable than from_keras_model() across TF/Keras versions
    import tempfile
    saved_dir = os.path.join(tempfile.mkdtemp(), "saved_model")
    model.export(saved_dir)
    tflite_bytes = tf.lite.TFLiteConverter.from_saved_model(saved_dir).convert()
    tflite_path = os.path.join(args.out, "transit_model.tflite")
    with open(tflite_path, "wb") as f:
        f.write(tflite_bytes)
    interp = tf.lite.Interpreter(model_content=tflite_bytes)
    interp.allocate_tensors()
    inp, out = interp.get_input_details()[0]["index"], interp.get_output_details()[0]["index"]
    diffs = []
    for i in range(0, min(len(Xte), 300)):
        interp.set_tensor(inp, Xte[i:i + 1])
        interp.invoke()
        diffs.append(abs(float(interp.get_tensor(out)[0][0]) - float(model.predict(Xte[i:i + 1], verbose=0)[0][0])))
    print(f"TFLite vs Keras max difference: {max(diffs):.2e}  ({os.path.getsize(tflite_path) / 1024:.1f} KB)")

    # Metadata the app needs (everything it shows must work with no server)
    mean_route_occ = df.groupby("route")["occupancy"].mean()
    hourly = df.groupby(["route", "hour"])["occupancy"].mean()
    route_meta = []
    for r in routes:
        sub = df[df["route"] == r]
        route_meta.append({
            "name": r,
            "mode": sub["mode"].mode().iloc[0],
            "capacity": float(sub["capacity"].median()),
            "stations": sorted(sub["station"].unique()),
            "hourly_mean_occ": [float(hourly.get((r, h), mean_route_occ[r])) for h in range(24)],
        })
    meta = {
        "routes": route_meta,
        "weathers": weathers,
        "default_weather": df["weather"].mode().iloc[0],
        "service_hours": sorted(int(h) for h in df["hour"].unique()),
        "feature_names": names,
        "rmse_occ": rmse_occ,
        "mean_ridership": float(df["ridership"].mean()),
        "metrics": {"model_mae": mae, "model_r2": r2, "baseline_mae": base_mae, "beats_baseline": bool(mae < base_mae)},
        "kpis": {
            "records": int(len(df)),
            "total_ridership": int(df["ridership"].sum()),
            "avg_ridership": int(df["ridership"].mean()),
            "peak_hour": int(df.groupby("hour")["ridership"].mean().idxmax()),
            "top_route": df.groupby("route")["ridership"].sum().idxmax(),
            "busiest_station": df.groupby("station")["ridership"].mean().idxmax(),
            "overcapacity_records": int((df["occupancy"] > 1).sum()),
        },
    }
    with open(os.path.join(args.out, "transit_meta.json"), "w") as f:
        json.dump(meta, f, indent=2)
    print("Wrote", tflite_path, "and transit_meta.json")


if __name__ == "__main__":
    main()
