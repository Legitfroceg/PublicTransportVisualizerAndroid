"""Build the Mumbai Suburban Railway assets for the offline Android app.

Everything the app ships is produced here:

    android/app/src/main/assets/mumbai_network.json         real line/station structure
    android/app/src/main/assets/transit_meta.json           encodings the model + UI use
    android/app/src/main/assets/transit_model.tflite        on-device delay model
    android/app/src/main/assets/mumbai_transit_dataset.csv.gz   large modelled operations dataset
    tflite_export/dataset_sample.csv                        small human-readable preview of the dataset

DATA PROVENANCE (read this):
  * NETWORK (`mumbai_network.json`, and the `line`/`station`/`station_code` columns) is REAL:
    line names, running order, station names and station codes are taken from the public
    Indian Railways / Wikipedia line references for the Mumbai Suburban Railway (see the
    `network_source` field). These are the stations a Mumbai commuter actually sees.
  * OPERATIONS (`ridership`, `occupancy_pct`, `crowd_*`, `delay_min`, `headway_min`, ...) are
    MODELLED. Indian Railways does not publish per-station / per-hour suburban delay or
    ridership data, so these columns are generated from a documented model of Mumbai
    commuting patterns. Every row is tagged `data_source = "modelled"`. Do NOT present the
    operational numbers as official railway figures.
"""

import gzip
import json
import os
import random
import sys

# TensorFlow 2.16 defaults to Keras 3, whose symbolic ops currently break the
# TFLite converter (LLVM "Failed to infer result type(s)"). Legacy Keras 2
# (the tf-keras package) exports the same model cleanly.
os.environ.setdefault("TF_USE_LEGACY_KERAS", "1")

import numpy as np
import pandas as pd
import tensorflow as tf

# ---------------------------------------------------------------------------
# 1. REAL NETWORK  (line -> ordered stations with real station codes)
# ---------------------------------------------------------------------------

NETWORK_SOURCE = (
    "Line order, station names and station codes from the public Mumbai Suburban "
    "Railway line references (Indian Railways / Wikipedia line articles, 2026)."
)

# (station name, station code)
NETWORK = [
    ("Western Line", "Western Line", "Churchgate", "Dahanu Road", [
        ("Churchgate", "CCG"), ("Marine Lines", "MEL"), ("Charni Road", "CYR"),
        ("Grant Road", "GTR"), ("Mumbai Central", "MMCT"), ("Mahalaxmi", "MX"),
        ("Lower Parel", "PL"), ("Prabhadevi", "PBHD"), ("Dadar", "DDR"),
        ("Matunga Road", "MRU"), ("Mahim Junction", "MM"), ("Bandra", "BA"),
        ("Khar Road", "KHAR"), ("Santacruz", "STC"), ("Vile Parle", "VLP"),
        ("Andheri", "ADH"), ("Jogeshwari", "JOS"), ("Ram Mandir", "RMAR"),
        ("Goregaon", "GMN"), ("Malad", "MDD"), ("Kandivli", "KILE"),
        ("Borivali", "BVI"), ("Dahisar", "DIC"), ("Mira Road", "MIRA"),
        ("Bhayandar", "BYR"), ("Naigaon", "NIG"), ("Vasai Road", "BSR"),
        ("Nallasopara", "NSP"), ("Virar", "VR"), ("Vaitarna", "VTN"),
        ("Saphale", "SAH"), ("Kelve Road", "KLV"), ("Palghar", "PLG"),
        ("Umroli", "UOI"), ("Boisar", "BOR"), ("Vangaon", "VGN"),
        ("Dahanu Road", "DRD"),
    ]),
    ("Central Line", "Central Line - Main", "Mumbai CSMT", "Kalyan Junction", [
        ("Chhatrapati Shivaji Maharaj Terminus", "CSMT"), ("Masjid", "MSD"),
        ("Sandhurst Road", "SNRD"), ("Byculla", "BY"), ("Chinchpokli", "CHP"),
        ("Currey Road", "CRD"), ("Parel", "PR"), ("Dadar", "D"),
        ("Matunga", "MTN"), ("Sion", "SIN"), ("Kurla", "C"),
        ("Vidyavihar", "VVH"), ("Ghatkopar", "G"), ("Vikhroli", "VK"),
        ("Kanjur Marg", "KJRD"), ("Bhandup", "BND"), ("Nahur", "NHU"),
        ("Mulund", "MLND"), ("Thane", "T"), ("Kalwa", "KLVA"),
        ("Mumbra", "MBQ"), ("Diva Junction", "DIVA"), ("Kopar", "KOPR"),
        ("Dombivli", "DI"), ("Thakurli", "THK"), ("Kalyan Junction", "KYN"),
    ]),
    ("Central Line", "Central Line - Kasara Branch", "Kalyan Junction", "Kasara", [
        ("Kalyan Junction", "KYN"), ("Shahad", "SHAD"), ("Ambivli", "ABY"),
        ("Titwala", "TWL"), ("Khadavli", "KDV"), ("Vasind", "VSD"),
        ("Asangaon", "ASO"), ("Atgaon", "ATG"), ("Thansit", "THS"),
        ("Khardi", "KE"), ("Umbermali", "OMB"), ("Kasara", "KSRA"),
    ]),
    ("Central Line", "Central Line - Khopoli Branch", "Kalyan Junction", "Khopoli", [
        ("Kalyan Junction", "KYN"), ("Vithalwadi", "VLDI"), ("Ulhasnagar", "ULNR"),
        ("Ambarnath", "ABH"), ("Chikhloli", "CHLI"), ("Badlapur", "BUD"),
        ("Vangani", "VGI"), ("Shelu", "SHLU"), ("Neral Junction", "NRL"),
        ("Bhivpuri Road", "BVS"), ("Karjat", "KJT"), ("Palasdhari", "PDI"),
        ("Kelavli", "KLY"), ("Dolavli", "DLV"), ("Lowjee", "LWJ"),
        ("Khopoli", "KHPL"),
    ]),
    ("Harbour Line", "Harbour Line - Main", "Mumbai CSMT", "Wadala Road", [
        ("Chhatrapati Shivaji Maharaj Terminus", "CSMT"), ("Masjid", "MSD"),
        ("Sandhurst Road", "SNRD"), ("Dockyard Road", "DKRD"), ("Reay Road", "RRD"),
        ("Cotton Green", "CTGN"), ("Sewri", "SVE"), ("Wadala Road", "VDLR"),
    ]),
    ("Harbour Line", "Harbour Line - Navi Mumbai", "Wadala Road", "Panvel", [
        ("Wadala Road", "VDLR"), ("Guru Tegh Bahadur Nagar", "GTBN"),
        ("Chunabhatti", "CHF"), ("Kurla", "C"), ("Tilak Nagar", "TKNG"),
        ("Chembur", "CMBR"), ("Govandi", "GV"), ("Mankhurd", "MNKD"),
        ("Vashi", "VSH"), ("Sanpada", "SNCR"), ("Juinagar", "JNJ"),
        ("Nerul", "NEU"), ("Seawoods-Darave-Karave", "SWDK"), ("CBD Belapur", "BEPR"),
        ("Kharghar", "KHAG"), ("Mansarovar", "MANR"), ("Khandeshwar", "KNDS"),
        ("Panvel", "PNVL"),
    ]),
    ("Harbour Line", "Harbour Line - Salsette (Goregaon)", "Wadala Road", "Goregaon", [
        ("Wadala Road", "VDLR"), ("King's Circle", "KCE"), ("Mahim Junction", "MM"),
        ("Bandra", "BA"), ("Khar Road", "KHAR"), ("Santacruz", "STC"),
        ("Vile Parle", "VLP"), ("Andheri", "ADH"), ("Jogeshwari", "JOS"),
        ("Ram Mandir", "RMAR"), ("Goregaon", "GMN"),
    ]),
    ("Trans-Harbour Line", "Trans-Harbour Line", "Thane", "Panvel", [
        ("Thane", "T"), ("Digha Gaon", "DIGH"), ("Airoli", "AIRL"),
        ("Rabale", "RABE"), ("Ghansoli", "GNSL"), ("Koparkhairane", "KPHN"),
        ("Turbhe", "TUH"), ("Sanpada", "SNCR"), ("Vashi", "VSH"),
        ("Juinagar", "JNJ"), ("Nerul", "NEU"), ("Seawoods-Darave-Karave", "SWDK"),
        ("CBD Belapur", "BEPR"), ("Kharghar", "KHAG"), ("Mansarovar", "MANR"),
        ("Khandeshwar", "KNDS"), ("Panvel", "PNVL"),
    ]),
    ("Port Line", "Port Line", "Nerul", "Uran", [
        ("Nerul", "NEU"), ("Seawoods-Darave-Karave", "SWDK"), ("CBD Belapur", "BEPR"),
        ("Targhar", "TRGR"), ("Bamandongri", "BMDR"), ("Kharkopar", "KARP"),
        ("Gavan", "GAVN"), ("Shematikhar", "SEMK"), ("Nhava Sheva", "NESA"),
        ("Dronagiri", "DRGI"), ("Uran", "URAN"),
    ]),
    ("Vasai Road-Roha Line", "Vasai Road-Roha Line", "Vasai Road", "Roha", [
        ("Vasai Road", "BSR"), ("Juchandra", "JCNR"), ("Kaman Road", "KARD"),
        ("Kharbao", "KHBV"), ("Bhiwandi Road", "BIRD"), ("Kopar", "KOPR"),
        ("Diva Junction", "DIVA"), ("Dativali", "DTVL"), ("Nilaje", "NIIJ"),
        ("Taloje Panchnand", "TPND"), ("Navde Road", "NVRD"), ("Kalamboli", "KLMC"),
        ("Panvel", "PNVL"), ("Somatne", "SMNE"), ("Rasayani", "RSYI"),
        ("Apta", "APTA"), ("Jite", "JITE"), ("Hamrapur", "HMRR"),
        ("Pen", "PEN"), ("Kasu", "KASU"), ("Nagothane", "NGTN"),
        ("Nidi", "NIDI"), ("Roha", "ROHA"),
    ]),
]

CANONICAL_LINES = []        # ordered unique line names used by the model + UI
STATION_CODE = {}           # station name -> station code
STATION_LINES = {}          # station name -> set of canonical lines
for _canon, _corridor, _a, _b, _stns in NETWORK:
    if _canon not in CANONICAL_LINES:
        CANONICAL_LINES.append(_canon)
    for _name, _code in _stns:
        STATION_CODE.setdefault(_name, _code)
        STATION_LINES.setdefault(_name, set()).add(_canon)

STATIONS = list(STATION_CODE.keys())  # ordered unique station names

INTERCHANGES = {s for s, ls in STATION_LINES.items() if len(ls) > 1}

TRANSIT_TYPES = ["Slow Local", "Fast Local", "AC Local"]
CROWD_LABELS = [
    "Low/Seated", "Moderate/Standing",
    "Heavy Crush Load", "Super Dense Crush Load (SDCL)",
]
WEATHER_CONDITIONS = ["Clear", "Light Rain", "Heavy Monsoon Rain", "Waterlogging"]

# Stations that carry the heaviest footfall in the real network.
MAJOR_STATIONS = {
    "Chhatrapati Shivaji Maharaj Terminus", "Churchgate", "Mumbai Central", "Dadar",
    "Bandra", "Kurla", "Andheri", "Borivali", "Ghatkopar", "Thane", "Mulund",
    "Dombivli", "Kalyan Junction", "Panvel", "Vashi", "Nerul", "Virar",
    "Goregaon", "Vasai Road", "Bhayandar",
}

# 12-car rakes: ~1168 seated + 2336 standing = 3504 (non-AC); AC rake ~3000.
CAPACITY = {"Slow Local": 3504, "Fast Local": 3504, "AC Local": 3000}

DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

# Monsoon months get most of the heavy rain and waterlogging.
MONTH_WEATHER_PROB = {
    "monsoon": [0.35, 0.30, 0.25, 0.10],   # Jun-Sep
    "post":    [0.60, 0.25, 0.12, 0.03],   # Oct-Nov
    "winter":  [0.85, 0.12, 0.03, 0.00],   # Dec-Feb
    "summer":  [0.75, 0.18, 0.06, 0.01],   # Mar-May
}

# One representative week per season (Jan / Apr / Jul / Oct).
REPRESENTATIVE_MONTHS = [1, 4, 7, 10]


def season_of(month):
    if 6 <= month <= 9:
        return "monsoon"
    if month in (10, 11):
        return "post"
    if month in (12, 1, 2):
        return "winter"
    return "summer"


# ---------------------------------------------------------------------------
# 2. MODELLED OPERATIONS MODEL  (documented, reproducible)
# ---------------------------------------------------------------------------

def station_weight(station):
    if station in INTERCHANGES:
        return 1.55
    if station in MAJOR_STATIONS:
        return 1.75
    return 1.0


def hour_factor(hour, station):
    """Mumbai commuter demand curve: twin peaks, quiet midday and night."""
    if hour in (8, 9, 10, 11):
        return 1.7 if hour == 9 else 1.45
    if hour in (17, 18, 19, 20, 21):
        return 1.75 if hour in (18, 19) else 1.4
    if 12 <= hour <= 16:
        return 0.75
    if hour <= 6:
        return 0.35
    return 0.55


def type_factor(t, hour):
    if t == "AC Local":
        return 0.85
    if t == "Fast Local":
        return 1.05 if hour in (8, 9, 10, 11, 17, 18, 19, 20, 21) else 0.7
    return 1.0  # Slow Local carries the base load


def is_peak(hour):
    return 8 <= hour <= 11 or 17 <= hour <= 21


def is_mega_block(day_index):
    return day_index == 6  # Sunday maintenance block


def crowd_index(hour, day_index):
    if is_peak(hour):
        return 3
    if is_mega_block(day_index) and hour > 10:
        return 2
    if 12 <= hour <= 16 or hour in (6, 7):
        return 1
    return 0


def delay_minutes(rng, hour, day_index, weather, line, station):
    """Modelled delay in minutes: monsoon and Sunday blocks dominate."""
    d = max(0.0, rng.gauss(2.0, 1.0))
    if weather == "Waterlogging":
        d += max(0.0, rng.gauss(25.0, 10.0))
    elif weather == "Heavy Monsoon Rain":
        d += max(0.0, rng.gauss(9.0, 4.0))
    elif weather == "Light Rain":
        d += max(0.0, rng.gauss(3.0, 2.0))
    if is_mega_block(day_index):
        d += max(0.0, rng.gauss(15.0, 5.0))
    if is_peak(hour):
        d += max(0.0, rng.gauss(2.5, 1.5))
    if station in INTERCHANGES:
        d += max(0.0, rng.gauss(1.0, 0.8))
    if line == "Vasai Road-Roha Line":
        d += 1.0  # MEMU corridor, longer headways
    return round(d, 1)


def ridership_value(rng, hour, day_index, weather, t, station):
    base = 1250.0
    occ_weather = {"Clear": 1.0, "Light Rain": 1.05,
                   "Heavy Monsoon Rain": 0.85, "Waterlogging": 0.6}[weather]
    weekend = 0.7 if day_index >= 5 else 1.0
    val = (base * station_weight(station) * hour_factor(hour, station)
           * type_factor(t, hour) * weekend * occ_weather)
    val *= rng.uniform(0.85, 1.15)
    return int(max(20.0, val))


def occupancy_pct(ridership, capacity):
    return round(ridership / capacity * 100.0, 1)


def risk_label(pct, delay):
    if delay >= 30 or pct > 100:
        return "Severe"
    if delay >= 15 or pct > 90:
        return "High"
    if delay >= 5 or pct > 75:
        return "Moderate"
    return "Low"


# ---------------------------------------------------------------------------
# 3. ASSET WRITERS
# ---------------------------------------------------------------------------

def assets_dir():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.normpath(os.path.join(here, "..", "android", "app", "src", "main", "assets"))


def build_meta():
    return {
        "version": "2.0.0",
        "city": "Mumbai",
        "lines": CANONICAL_LINES,
        "stations": STATIONS,
        "transit_types": TRANSIT_TYPES,
        "crowd_labels": CROWD_LABELS,
        "weather_conditions": WEATHER_CONDITIONS,
        "network_file": "mumbai_network.json",
        "dataset_file": "mumbai_transit_dataset.csv.gz",
        "network_source": NETWORK_SOURCE,
    }


def build_network():
    lines = []
    for canon, corridor, start, end, stations in NETWORK:
        lines.append({
            "line": canon,
            "corridor": corridor,
            "termini": [start, end],
            "stations": [
                {
                    "sequence": i + 1,
                    "name": name,
                    "code": code,
                    "interchange": name in INTERCHANGES,
                }
                for i, (name, code) in enumerate(stations)
            ],
        })
    return {
        "city": "Mumbai",
        "version": "2.0.0",
        "network_source": NETWORK_SOURCE,
        "station_codes_note": "Station codes are the public Indian Railways codes.",
        "lines": lines,
    }


def build_dataset(num_samples=None):
    """Return a DataFrame of modelled operations across the real network."""
    rng = random.Random(42)
    rows = []
    rid = 0
    for canon, corridor, _start, _end, stations in NETWORK:
        for seq, (station, code) in enumerate(stations, start=1):
          for month in REPRESENTATIVE_MONTHS:
            season = season_of(month)
            for day_index in range(7):
                for hour in range(4, 24):
                    weather = rng.choices(WEATHER_CONDITIONS,
                                          weights=MONTH_WEATHER_PROB[season], k=1)[0]
                    for t in TRANSIT_TYPES:
                        ridership = ridership_value(rng, hour, day_index, weather, t, station)
                        cap = CAPACITY[t]
                        occ = occupancy_pct(ridership, cap)
                        delay = delay_minutes(rng, hour, day_index, weather, canon, station)
                        ci = crowd_index(hour, day_index)
                        rid += 1
                        rows.append({
                            "record_id": rid,
                            "service_date": f"2026-{month:02d}-{day_index + 5:02d}",
                            "hour_of_day": hour,
                            "day_of_week": day_index,
                            "day_name": DAY_NAMES[day_index],
                            "is_weekend": int(day_index >= 5),
                            "is_peak": int(is_peak(hour)),
                            "is_mega_block": int(is_mega_block(day_index)),
                            "season": season,
                            "month": month,
                            "line": canon,
                            "corridor": corridor,
                            "station": station,
                            "station_code": code,
                            "sequence_no": seq,
                            "is_interchange": int(station in INTERCHANGES),
                            "commute_type": t,
                            "weather_condition": weather,
                            "train_capacity": cap,
                            "headway_min": 3 if is_peak(hour) else 7,
                            "ridership": ridership,
                            "occupancy_pct": occ,
                            "crowd_index": ci,
                            "crowd_label": CROWD_LABELS[ci],
                            "delay_min": delay,
                            "service_status": risk_label(occ, delay),
                            "data_source": "modelled",
                        })
    df = pd.DataFrame(rows)
    if num_samples and len(df) > num_samples:
        df = df.sample(n=num_samples, random_state=42).reset_index(drop=True)
    return df


# ---------------------------------------------------------------------------
# 4. TRAIN + EXPORT
# ---------------------------------------------------------------------------

def build_model():
    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(6,)),
        tf.keras.layers.Dense(64, activation="relu"),
        tf.keras.layers.Dense(32, activation="relu"),
        tf.keras.layers.Dense(16, activation="relu"),
        tf.keras.layers.Dense(1, activation="linear"),
    ])
    model.compile(optimizer="adam", loss="mse", metrics=["mae"])
    return model


def main(num_samples=None):
    out = assets_dir()
    os.makedirs(out, exist_ok=True)

    # 1) real network
    with open(os.path.join(out, "mumbai_network.json"), "w", encoding="utf-8") as f:
        json.dump(build_network(), f, indent=2)
        f.write("\n")

    # 2) encodings + metadata
    with open(os.path.join(out, "transit_meta.json"), "w", encoding="utf-8") as f:
        json.dump(build_meta(), f, indent=2)
        f.write("\n")

    # 3) large modelled operations dataset (bundled, gzipped) + a small preview
    df = build_dataset(num_samples)
    csv_path = os.path.join(out, "mumbai_transit_dataset.csv.gz")
    with gzip.open(csv_path, "wt", encoding="utf-8", newline="") as f:
        df.to_csv(f, index=False)
    sample_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dataset_sample.csv")
    df.head(300).to_csv(sample_path, index=False)

    # 4) train the delay model on the dataset (real line/station encodings)
    line_idx = {n: i for i, n in enumerate(CANONICAL_LINES)}
    stn_idx = {n: i for i, n in enumerate(STATIONS)}
    typ_idx = {n: i for i, n in enumerate(TRANSIT_TYPES)}
    wx_idx = {n: i for i, n in enumerate(WEATHER_CONDITIONS)}

    X = np.column_stack([
        df["hour_of_day"].to_numpy(np.float32),
        df["day_of_week"].to_numpy(np.float32),
        df["line"].map(line_idx).to_numpy(np.float32),
        df["station"].map(stn_idx).to_numpy(np.float32),
        df["commute_type"].map(typ_idx).to_numpy(np.float32),
        df["weather_condition"].map(wx_idx).to_numpy(np.float32),
    ])
    y = df["delay_min"].to_numpy(np.float32)

    model = build_model()
    model.fit(X, y, epochs=6, batch_size=512, validation_split=0.2, verbose=0)

    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    tflite_model = converter.convert()
    with open(os.path.join(out, "transit_model.tflite"), "wb") as f:
        f.write(tflite_model)

    print(f"network: {len(NETWORK)} corridors, {len(CANONICAL_LINES)} lines, "
          f"{len(STATIONS)} stations ({len(INTERCHANGES)} interchanges)")
    print(f"dataset: {len(df):,} rows x {len(df.columns)} columns -> {csv_path}")
    print(f"wrote transit_meta.json, mumbai_network.json, transit_model.tflite to {out}")


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else None)
